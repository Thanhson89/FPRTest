package mathsat;

public interface SolveDiversifyModelCallback {
    public int callback(long model_iterator);
}
